import json
from dataclasses import dataclass, field
from urllib.parse import urljoin

import aiohttp

from astrbot import logger

from .qqmusic_auth import get_device_path, load_credential

try:
    from qqmusic_api import Client as QMClient
    from qqmusic_api.modules.search import SearchType
    from qqmusic_api.modules.song import SongFileInfo, SongFileType

    QQ_MUSIC_AVAILABLE = True
except ImportError:
    QQ_MUSIC_AVAILABLE = False
    logger.warning("qqmusic-api-python not installed, QQ Music features disabled")

# 偷来的key
PARAMS = "D33zyir4L/58v1qGPcIPjSee79KCzxBIBy507IYDB8EL7jEnp41aDIqpHBhowfQ6iT1Xoka8jD+0p44nRKNKUA0dv+n5RWPOO57dZLVrd+T1J/sNrTdzUhdHhoKRIgegVcXYjYu+CshdtCBe6WEJozBRlaHyLeJtGrABfMOEb4PqgI3h/uELC82S05NtewlbLZ3TOR/TIIhNV6hVTtqHDVHjkekrvEmJzT5pk1UY6r0="
ENC_SEC_KEY = "45c8bcb07e69c6b545d3045559bd300db897509b8720ee2b45a72bf2d3b216ddc77fb10daec4ca54b466f2da1ffac1e67e245fea9d842589dc402b92b262d3495b12165a721aed880bf09a0a99ff94c959d04e49085dc21c78bbbe8e3331827c0ef0035519e89f097511065643120cbc478f9c0af96400ba4649265781fc9079"


class NetEaseMusicAPI:
    """
    网易云音乐API
    """

    def __init__(self):
        self.header = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) "
            "Chrome/55.0.2883.87 UBrowser/6.2.4098.3 Safari/537.36"
        }
        self.headers = {"referer": "http://music.163.com"}
        self.cookies = {"appver": "2.0.2"}
        self._session = None

    @property
    def session(self):
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=20)
            )
        return self._session

    async def _request(
        self,
        url: str,
        data: dict | None = None,
        method: str = "GET",
    ):
        """统一请求接口"""
        if method.upper() == "POST":
            async with self.session.post(
                url, headers=self.header, cookies=self.cookies, data=data or {}
            ) as response:
                if response.headers.get("Content-Type") == "application/json":
                    return await response.json()
                else:
                    return json.loads(await response.text())

        elif method.upper() == "GET":
            async with self.session.get(
                url, headers=self.headers, cookies=self.cookies
            ) as response:
                return await response.json()
        else:
            raise ValueError("不支持的请求方式")

    async def fetch_data(self, keyword: str, limit=5) -> list[dict]:
        """搜索歌曲"""
        url = "http://music.163.com/api/search/get/web"
        data = {"s": keyword, "limit": limit, "type": 1, "offset": 0}
        result = await self._request(url, data=data, method="POST")
        if (
            not isinstance(result, dict)
            or "result" not in result
            or not result["result"]
        ):
            logger.warning(f"网易云API搜索返回异常格式: {result}")
            return []
        songs = result["result"].get("songs", []) or []
        return [
            {
                "id": song["id"],
                "name": song["name"],
                "artists": "、".join(artist["name"] for artist in song["artists"]),
                "duration": song["duration"],
            }
            for song in songs[:limit]
        ]

    async def fetch_comments(self, song_id: int):
        """获取热评"""
        url = f"https://music.163.com/weapi/v1/resource/hotcomments/R_SO_4_{song_id}?csrf_token="
        data = {
            "params": PARAMS,
            "encSecKey": ENC_SEC_KEY,
        }
        result = await self._request(url, data=data, method="POST")
        return result.get("hotComments", [])

    async def fetch_lyrics(self, song_id):
        """获取歌词"""
        url = f"https://netease-music.api.harisfox.com/lyric?id={song_id}"
        result = await self._request(url)
        return result.get("lrc", {}).get("lyric", "歌词未找到")

    async def fetch_extra(self, song_id: str | int) -> dict[str, str]:
        """
        获取额外信息
        """
        url = f"https://www.hhlqilongzhu.cn/api/dg_wyymusic.php?id={song_id}&br=7&type=json"
        result = await self._request(url)
        return {
            "title": result.get("title"),
            "author": result.get("singer"),
            "cover_url": result.get("cover"),
            "audio_url": result.get("music_url"),
        }

    async def close(self):
        if self._session is not None and not self._session.closed:
            await self._session.close()


class NetEaseMusicAPINodeJs:
    """
    网易云音乐API NodeJs版本
    """

    def __init__(self, base_url: str):
        # http://netease_cloud_music_api:{port}/
        self.base_url = base_url
        self._session = None

    @property
    def session(self):
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                self.base_url, timeout=aiohttp.ClientTimeout(total=20)
            )
        return self._session

    async def _request(self, url: str, data: dict | None = None, method: str = "GET"):
        if method.upper() == "POST":
            async with self.session.post(url, data=data or {}) as response:
                if response.headers.get("Content-Type") == "application/json":
                    return await response.json()
                else:
                    return json.loads(await response.text())
        elif method.upper() == "GET":
            async with self.session.get(url) as response:
                return await response.json()
        else:
            raise ValueError("不支持的请求方式")

    async def fetch_data(self, keyword: str, limit=5) -> list[dict]:
        """搜索歌曲"""
        url = "/search"
        data = {"keywords": keyword, "limit": limit, "type": 1, "offset": 0}

        result = await self._request(url, data=data, method="POST")
        if (
            not isinstance(result, dict)
            or "result" not in result
            or not result["result"]
        ):
            logger.warning(f"网易云NodeJs API搜索返回异常格式: {result}")
            return []
        songs = result["result"].get("songs", []) or []
        res = [
            {
                "id": song["id"],
                "name": song["name"],
                "artists": "、".join(artist["name"] for artist in song["artists"]),
                "duration": song["duration"],
            }
            for song in songs[:limit]
        ]

        return res

    async def fetch_comments(self, song_id: int):
        """获取热评"""
        url = "/comment/hot"
        data = {
            "id": song_id,
            "type": 0,
        }
        result = await self._request(url, data=data, method="POST")
        return result.get("hotComments", [])

    async def fetch_lyrics(self, song_id):
        """获取歌词"""
        url = f"{self.base_url}/lyric?id={song_id}"
        result = await self._request(url)
        return result.get("lrc", {}).get("lyric", "歌词未找到")

    async def fetch_extra(self, song_id: str | int) -> dict[str, str]:
        """
        获取额外信息
        """
        url = "/song/url"
        data = {"id": song_id}
        result = await self._request(url, data=data, method="POST")
        return {"audio_url": result["data"][0].get("url", "")}

    async def close(self):
        if self._session is not None and not self._session.closed:
            await self._session.close()


@dataclass(frozen=True)
class SongAudioSource:
    url: str = field(repr=False)
    quality: str
    extension: str


class QQMusicAPI:
    """
    QQ音乐API (基于qqmusic-api-python库)

    支持功能：
    - 搜索歌曲
    - 获取歌曲详情
    - 获取播放链接
    """

    def __init__(self, api_key: str = None):
        """
        初始化QQ音乐API
        """
        if not QQ_MUSIC_AVAILABLE:
            raise ImportError("qqmusic-api-python not installed")
        self._client = None
        self.api_key = api_key

    async def _get_client(self):
        """获取或创建客户端"""
        if self._client is None:
            credential = None
            try:
                credential = load_credential()
            except Exception as exc:
                logger.warning(
                    "QQ Music credential could not be loaded: %s", type(exc).__name__
                )
            self._client = QMClient(
                credential=credential, device_path=get_device_path()
            )
            await self._client.__aenter__()
        return self._client

    async def fetch_data(self, keyword: str, limit: int = 5) -> list[dict]:
        """搜索歌曲

        Args:
            keyword: 搜索关键词
            limit: 返回数量限制

        Returns:
            歌曲列表，每首歌曲包含 id, name, artists, duration 等信息
        """
        try:
            client = await self._get_client()
            result = await client.search.search_by_type(
                keyword=keyword, num=limit, search_type=SearchType.SONG
            )

            songs = []
            for song in result.song[:limit]:
                artists = (
                    "、".join(s.name for s in song.singer) if song.singer else "未知"
                )
                songs.append(
                    {
                        "id": song.mid or str(song.id),
                        "name": song.name or song.title,
                        "artists": artists,
                        "duration": song.interval * 1000 if song.interval else 0,
                        "album": song.album.name if song.album else "",
                        "songmid": song.mid,
                    }
                )
            return songs
        except Exception as e:
            logger.error(f"QQ音乐搜索失败: {e}")
            return []

    async def fetch_song_detail(self, songmid: str) -> dict:
        """获取歌曲详情"""
        try:
            client = await self._get_client()
            result = await client.song.get_detail(songmid)
            track = result.track
            return {
                "name": track.name,
                "singer": [{"name": s.name} for s in track.singer],
                "album": {"name": track.album.name, "mid": track.album.mid},
                "interval": track.interval,
            }
        except Exception as e:
            logger.error(f"获取歌曲详情失败: {e}")
            return {}

    async def fetch_song_sources(
        self, songmid: str, quality: str = "best"
    ) -> list[SongAudioSource]:
        """Return authorized stereo audio files, ordered by preferred quality.

        Ask for all formats in one request, matching responses by filename so
        absent permissions or reordered results cannot change the chosen song.
        Encrypted/proprietary and surround-only formats are not requested.
        """
        formats = [
            (SongFileType.MASTER, "母带 FLAC"),
            (SongFileType.ATMOS_2, "臻品 FLAC"),
            (SongFileType.FLAC, "无损 FLAC"),
            (SongFileType.OGG_640, "OGG 640"),
            (SongFileType.OGG_320, "OGG 320"),
            (SongFileType.MP3_320, "MP3 320"),
            (SongFileType.OGG_192, "OGG 192"),
            (SongFileType.ACC_192, "AAC 192"),
            (SongFileType.MP3_128, "MP3 128"),
            (SongFileType.OGG_96, "OGG 96"),
            (SongFileType.ACC_96, "AAC 96"),
            (SongFileType.ACC_48, "AAC 48"),
        ]
        if quality == "320":
            formats = [
                item
                for item in formats
                if item[0]
                in {
                    SongFileType.MP3_320,
                    SongFileType.MP3_128,
                    SongFileType.ACC_96,
                    SongFileType.ACC_48,
                }
            ]
        elif quality == "128":
            formats = formats[8:]
        elif quality == "flac":
            formats = formats[2:]
        elif quality not in {"best", "auto"}:
            raise ValueError("Unsupported QQ Music quality")
        client = await self._get_client()
        detail = await client.song.get_detail(songmid)
        track = detail.track
        media_mid = getattr(getattr(track, "file", None), "media_mid", None)
        requests = [
            SongFileInfo(
                mid=songmid,
                media_mid=media_mid,
                song_type=getattr(track, "type", 0),
                file_type=file_type,
            )
            for file_type, _ in formats
        ]
        result = await client.song.get_song_urls(requests)
        authorized = {
            item.filename: item.purl
            for item in result.data or []
            if item.result == 0 and item.purl and item.mid == songmid
        }
        if not authorized:
            return []
        cdn = await client.song.get_cdn_dispatch()
        if not cdn.sip:
            return []
        sources = []
        for file_type, label in formats:
            filename = (
                f"{file_type.s}{media_mid}{file_type.e}"
                if media_mid
                else f"{file_type.s}{songmid}{songmid}{file_type.e}"
            )
            if filename in authorized:
                sources.append(
                    SongAudioSource(
                        url=urljoin(cdn.sip[0], authorized[filename]),
                        quality=label,
                        extension=file_type.e,
                    )
                )
        return sources

    async def fetch_song_url(
        self,
        songmid: str,
        song_name: str = "",
        quality: str = "best",
        official_only: bool = False,
    ) -> str:
        """获取歌曲播放链接（支持多种方式）

        Args:
            songmid: 歌曲ID (QQ音乐mid)
            song_name: 歌曲名称（用于备选API搜索）
            quality: best/auto prioritizes authorized high-quality stereo audio.
            official_only: Only return the selected song's official audio URL.

        Returns:
            播放链接URL
        """
        # 方式1：使用官方API
        try:
            sources = await self.fetch_song_sources(songmid, quality=quality)
            if sources:
                logger.info("QQ Music selected quality: %s", sources[0].quality)
                return sources[0].url
        except Exception as e:
            logger.error(f"官方API获取失败: {e}")

        if official_only:
            return ""

        # 方式2：使用第三方免费API（支持付费歌曲）
        if self.api_key:
            try:
                import json

                import aiohttp

                search_keyword = song_name or songmid
                async with aiohttp.ClientSession() as session:
                    url = f"https://jkapi.com/api/music?plat=qq&type=json&apiKey={self.api_key}&name={search_keyword}"
                    async with session.get(
                        url, timeout=aiohttp.ClientTimeout(total=15)
                    ) as resp:
                        if resp.status == 200:
                            text = await resp.text()
                            data = json.loads(text)
                            if data.get("code") == 1 and data.get("music_url"):
                                logger.info(f"第三方API获取成功: {search_keyword}")
                                return data["music_url"]
            except Exception as e:
                logger.error(f"第三方API获取失败: {e}")

        # 方式3：使用另一个备选API
        try:
            import aiohttp

            async with aiohttp.ClientSession() as session:
                url = f"https://api.lolimi.cn/API/wy/api.php?msg={song_name or songmid}&n=1"
                async with session.get(
                    url, timeout=aiohttp.ClientTimeout(total=15)
                ) as resp:
                    if resp.status == 200:
                        data = await resp.json()
                        if (
                            data.get("code") == 200
                            and data.get("data")
                            and data["data"].get("music")
                        ):
                            logger.info(f"备选API2获取成功: {song_name or songmid}")
                            return data["data"]["music"]
                        elif data.get("code") == 200 and data.get("music_url"):
                            logger.info(f"备选API2获取成功: {song_name or songmid}")
                            return data["music_url"]
        except Exception as e:
            logger.error(f"备选API2获取失败: {e}")

        return ""

    async def fetch_lyrics(self, songmid: str) -> str:
        """获取歌词"""
        try:
            client = await self._get_client()
            result = await client.song.get_lyric(songmid)
            return result.lyric or "歌词未找到"
        except Exception as e:
            logger.error(f"获取歌词失败: {e}")
            return "歌词未找到"

    async def fetch_extra(self, song_id: str | int) -> dict[str, str]:
        """获取额外信息（封面、音频URL等）"""
        try:
            detail = await self.fetch_song_detail(str(song_id))
            audio_url = await self.fetch_song_url(str(song_id))

            cover_url = ""
            if detail.get("album", {}).get("mid"):
                cover_url = f"https://y.gtimg.cn/music/photo_new/T002R300x300M000{detail['album']['mid']}.jpg"

            return {
                "title": detail.get("name", ""),
                "author": "、".join(s["name"] for s in detail.get("singer", []))
                if detail.get("singer")
                else "",
                "cover_url": cover_url,
                "audio_url": audio_url,
            }
        except Exception as e:
            logger.error(f"获取额外信息失败: {e}")
            return {"title": "", "author": "", "cover_url": "", "audio_url": ""}

    async def close(self):
        if self._client is not None:
            try:
                await self._client.__aexit__(None, None, None)
            except Exception:
                pass
            finally:
                self._client = None


class MusicSearcher:
    """
    用于从指定音乐平台搜索歌曲信息的工具类。

    支持的平台：
    - qq: QQ 音乐
    - netease: 网易云音乐
    - kugou: 酷狗音乐
    - kuwo: 酷我音乐
    - baidu: 百度音乐
    - 1ting: 一听音乐
    - migu: 咪咕音乐
    - lizhi: 荔枝FM
    - qingting: 蜻蜓FM
    - ximalaya: 喜马拉雅
    - 5singyc: 5sing原创
    - 5singfc: 5sing翻唱
    - kg: 全民K歌

    支持的过滤条件：
    - name: 按歌曲名称搜索（默认）
    - id: 按歌曲 ID 搜索
    - url: 按音乐地址（URL）搜索
    """

    def __init__(self):
        """初始化请求 URL 和请求头"""
        self.base_url = "https://music.txqq.pro/"
        self.headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/132.0.0.0 Safari/537.36 Edg/132.0.0.0",
            "Accept": "application/json, text/javascript, */*; q=0.01",
            "X-Requested-With": "XMLHttpRequest",
        }
        self._session = None

    @property
    def session(self):
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession()
        return self._session

    async def fetch_data(self, song_name: str, platform_type: str, limit: int = 5):
        """
        向音乐接口发送 POST 请求以获取歌曲数据

        :param song_name: 要搜索的歌曲名称
        :param platform_type: 音乐平台类型，如 'qq', 'netease' 等
        :return: 返回解析后的 JSON 数据或 None
        """
        data = {
            "input": song_name,
            "filter": "name",  # 当前固定为按名称搜索
            "type": platform_type,
            "page": 1,
        }

        try:
            async with self.session.post(
                self.base_url, data=data, headers=self.headers
            ) as response:
                if response.status == 200:
                    result = await response.json()
                    if (
                        not isinstance(result, dict)
                        or "songs" not in result
                        or not result["songs"]
                    ):
                        logger.warning(f"聚合音乐API搜索返回异常格式: {result}")
                        return []
                    return [
                        {
                            "id": song["songid"],
                            "name": song.get("title", "未知"),
                            "artists": song.get("author", "未知"),
                            "url": song.get("url", "无"),
                            "link": song.get("link", "无"),
                            "lyrics": song.get("lrc", "无"),
                            "cover_url": song.get("pic", "无"),
                        }
                        for song in result["songs"][:limit]
                    ]
                else:
                    logger.error(f"请求失败:{response.status}")
                    return None
        except Exception as e:
            logger.error(f"请求异常: {e}")
            return None

    async def close(self):
        await self.session.close()
